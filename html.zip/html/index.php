<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>London Musk | Home</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/cfe2f4d7d5.js" crossorigin="anonymous"></script>
<link href="owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="owl-carousel/owl.theme.css" rel="stylesheet">
<link href="owl-carousel/owl.transitions.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="mobile_menu/css/style_menu.css">
<link rel="stylesheet" type="text/css" href="mobile_menu/css/ionicon.min.css">
</head>
<body>
<?php include("header.php"); ?>
<section class="slider_section"><img src="images/banner.jpg" width="1349" height="500" alt="" /></section>
<section class="banner_bottom">Free UK Shipping Over £30</section>
<section class="new_arrival_section"> <img src="images/new_arrivals_img.png" class="new_arrival_img" width="192" height="504" alt="" />
  <div class="container">
    <div class="row">
      <div class="col-md-4 new_arrival_left">
        <h3 class="product_header">New Arrival</h3>
        <p>Be enthralled by our plethora of new products. We have integrated new products in our assemblage,
          that is of supreme quality. These new products will</p>
        <div><a class="btn_explore_now" href="#">Explore now</a></div>
      </div>
      <div class="col-md-8">
        <div id="owl-new_arrival" class="owl-carousel">
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img1.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img2.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img3.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img1.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img2.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img3.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="oud_fragrances_back">
  <div class="container">
    <div class="row">
      <div class="col-md-8 pt-5 mt-4">
        <h2>Best Oud Fragrances For Men 2022</h2>
        <p>London musk from its inception has been preeminently working to ensure high-quality products for our valuable customers. We, as a customer-oriented organization, value what our customer needs. We try to offer products that are of high standard, so that our customers are satisfied. The perfumes we offer are of the best quality and we source them from premium consortiums, so they are of international standard. It’s important to note that all our products are halal and we try to sell halal perfumes and halal attars.<br/>
          <br/>
          London Musk provides 100% pure Arabian perfumes London. We possess years of experience in this industry and have earned the reputation of being reliable and trusted in offering quality scents. At London Musk, you will find a great variety of perfumes for both men and women. They are made using pure materials and are halal. Moreover, we assure you that you will find the specific products that you love to call your own. You will find the ideal perfume, whether you are buying it for yourself or giving it as a gift to someone special. Our perfumes are suitable for various occasions.<br/>
          <br/>
          For several years, we have been working passionately to provide quality Oud Perfume London to our valuable customers. Our wide-rage of products are for both men and women and are available at affordable prices. Oud Al Anfar is one of our popular products because of its pure fragrance, and we are the official distributor of this perfume. </p>
      </div>
    </div>
  </div>
</section>
<section class="category_section mt-5">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="category_header">Discover Categories</h1>
      </div>
      <div class="col-md-4">
        <div class="category_inner"> <a href="#">Fragrances</a> <img src="images/category1.jpg" width="380" height="380" alt="" /></div>
      </div>
      <div class="col-md-4">
        <div class="category_inner"><a href="#">Gift Sets</a> <img src="images/category2.jpg" width="380" height="380" alt="" /></div>
      </div>
      <div class="col-md-4">
        <div class="category_inner"><a href="#">Fragrance Oils</a> <img src="images/category3.jpg" width="380" height="380" alt="" /></div>
      </div>
    </div>
  </div>
</section>
<section class="new_best_seller mt-5"> <img src="images/best_sellers_img_right.png" class="best_seller_img" width="192" height="504" alt="" />
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <div id="owl-best_seller" class="owl-carousel">
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img1.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img2.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img3.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img1.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img2.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-12">
              <div class="product_box">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="product_box_img"><img src="images/product_img3.jpg" width="231" height="231" alt="" /></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4 best_seller_left">
        <h3 class="product_header">Best Sellers</h3>
        <p>Check out our best selling products. We have integrated new products in our assemblage, that is of supreme quality. These new products will surely beguile you. </p>
        <div><a class="btn_explore_now2" href="#">Explore now</a></div>
      </div>
    </div>
  </div>
</section>
<section class="delivery_option pt-5 pb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="delivery_option_inner">
          <table cellspacing="0" cellpadding="0" border="0">
            <tbody>
              <tr>
                <td><img src="images/icon1.png" alt="" width="88" height="74"></td>
              </tr>
              <tr>
                <td class="delivery_option_inner_text">Free Shipping<br/>
                  Above £30</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-3">
        <div class="delivery_option_inner">
          <table cellspacing="0" cellpadding="0" border="0">
            <tbody>
              <tr>
                <td><img src="images/icon2.png" alt="" width="88" height="74"></td>
              </tr>
              <tr>
                <td class="delivery_option_inner_text">100% Money Back<br/>
                  Guarantee</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-3">
        <div class="delivery_option_inner">
          <table cellspacing="0" cellpadding="0" border="0">
            <tbody>
              <tr>
                <td><img src="images/brand.png" alt="" width="88" height="74"></td>
              </tr>
              <tr>
                <td class="delivery_option_inner_text">Authentic<br/>
                  Brands</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-3">
        <div class="delivery_option_inner">
          <table cellspacing="0" cellpadding="0" border="0">
            <tbody>
              <tr>
                <td><img src="images/checkout_icon.png" alt="" width="88" height="74"></td>
              </tr>
              <tr>
                <td class="delivery_option_inner_text">Secure<br/>
                  Checkout</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="newsletter_section pt-4 pb-4">
  <div class="container">
    <div class="row">
      <div class="col-md-6 mx-auto">
        <h3 class="text-center newsletter_header">Stay Updated</h3>
        <p class="text-center">Sign up for latest offers and promotions</p>
        <form action="" method="post">
          <input type="text" placeholder="Enter Email Address" class="form-control custom_fild" name="newsletter_email" id="newsletter_email">
          <input type="submit" value="Join" class="btn custom_btn" name="newsletter_btn">
        </form>
        <center>
          <img src="images/trulstpilot.jpg" width="271" height="36" alt="" />
        </center>
      </div>
    </div>
  </div>
</section>
<section class="instagram_section "> <img src="images/ins_back.jpg" width="1349" height="520" alt="" /></section>
<?php include("footer.php"); ?>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script defer src="mobile_menu/js/script.js"></script>
<script src="owl-carousel/owl.carousel.js"></script>
<script type="text/javascript">
 $("#owl-new_arrival").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 2],
			[700, 2],
			[1000, 3],
			[1200,3],
			[1400, 3],
			[1600, 3]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	   $("#owl-best_seller").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 2],
			[700, 2],
			[1000, 3],
			[1200,3],
			[1400, 3],
			[1600, 3]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	  
	  
	  
	  
	   $("#owl-product_slider").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 1],
			[700, 1],
			[1000, 1],
			[1200,1],
			[1400, 1],
			[1600, 1]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
   </script>
</html>
<header>
  <div class="container">
    <div class="row">
      <div class="col-md-4 sign_in">
        <table  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="40"><img src="images/user_icon.png" width="30" height="30" alt="" /></td>
            <td><a href="#">Sign in</a></td>
          </tr>
        </table>
      </div>
      <div class="col-md-4 logo"><a href="#"><img src="images/logo.png" width="83" height="98" alt="" /></a></div>
      <div class="col-md-4 top_right">
        <ul>
          <li><a href="#"><img src="images/search_icon.png" width="29" height="29" alt="" /></a></li>
          <li><a href="#"><span class="cart_count">3</span><img src="images/wishlist.png" width="35" height="29" alt="" /></a></li>
          <li><a href="#"><span class="cart_count">3</span><img src="images/cart_icon.png" width="40" height="34" alt="" /></a></li>
        </ul>
      </div>
    </div>
  </div>
</header>
<section class="menu_section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <button type="button" class="opened-menu"> <span></span> <span></span> <span></span> <span></span> </button>
        <div class="overlay"></div>
        <nav class="navbar custom_menu clearfix">
          <button type="button" class="closed-menu"> <img src="images/closed.svg" class="closed-icon" alt="closed"> </button>
          <ul class="menu">
            <!--   <li class="menu-item  menu-item-has-children"><a href="#" class="">Wardrobes</a><a href="#" class="icon_expand"  data-toggle="sub-menu"><i class="expand"></i></a>
              <ul class="sub-menu">
                <li class="menu-item "><a href="#">Sliding</a></li>
                <li class="menu-item "><a href="#">Hinged</a></li>
                <li class="menu-item "><a href="#">Mirrored</a></li>
                <li class="menu-item "><a href="#">Corner</a></li>
                <li class="menu-item "><a href="#">Drawer</a></li>
              </ul>
            </li>
            <li class="menu-item  "><a href="#" class="">Wardrobe Sets</a></li>
            <li class="menu-item  menu-item-has-children"><a href="#" class="">Bedroom Furniture</a><a href="#" class="icon_expand"  data-toggle="sub-menu"><i class="expand"></i></a>
              <ul class="sub-menu">
                <li class="menu-item "><a href="#">Beds</a></li>
                <li class="menu-item "><a href="#">Bedside Cabinet</a></li>
                <li class="menu-item "><a href="#">Headboards</a></li>
                <li class="menu-item "><a href="#">Chest of Drawers</a></li>
                <li class="menu-item "><a href="#">Mattresses</a></li>
                <li class="menu-item "><a href="#">Dressing Table</a></li>
                <li class="menu-item "><a href="#">Overbed Unit</a></li>
                <li class="menu-item "><a href="#">Bedroom Sets</a></li>
                <li class="menu-item "><a href="#">Bedroom Stool</a></li>
                <li class="menu-item "><a href="#">Bedroom Chair</a></li>
                <li class="menu-item "><a href="#">Bedroom Mirrors</a></li>
                <li class="menu-item "><a href="#">Bedroom Storage</a></li>
              </ul>
            </li>-->
            
            <li class="menu-item"><a href="#" class="">Home</a></li>
            <li class="menu-item"><a href="#" class="">Spray Perfumes</a></li>
            <li class="menu-item"><a href="#" class="">Fragrance Oils</a></li>
            <li class="menu-item"><a href="#" class="">Gift Sets</a></li>
            <li class="menu-item"><a href="#" class="">Car Air Freshner</a></li>
            <li class="menu-item"><a href="#" class="">Home Fragrance</a></li>
            <li class="menu-item"><a href="#" class="">Wholesale Oil</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</section>

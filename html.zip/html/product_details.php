<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>London Musk</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/cfe2f4d7d5.js" crossorigin="anonymous"></script>
<link href="owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="owl-carousel/owl.theme.css" rel="stylesheet">
<link href="owl-carousel/owl.transitions.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="mobile_menu/css/style_menu.css">
<link rel="stylesheet" type="text/css" href="mobile_menu/css/ionicon.min.css">
</head>
<body>
<?php include("header.php"); ?>
<section class="section sub_banner_section clearfix" style="background:none;">
  <div class="container">
    <div class="row">
      <div class="col-md-12"> <a href="#">Home</a> / Spray Perfumes </div>
    </div>
  </div>
</section>
<section class="product_listing_section pt-2 pb-5" style="background:none;">
  <div class="container">
    <div class="row">
      <div class="col-md-6 product_details_left">
        <div id="owl-product_gallery" class="owl-carousel owl-theme">
          <div class="item"><img src="images/product_details_img.jpg" width="537" height="856" alt=""></div>
          <div class="item"><img src="images/product_details_img.jpg" width="537" height="856" alt=""></div>
          <div class="item"><img src="images/product_details_img.jpg" width="537" height="856" alt=""></div>
          <div class="item"><img src="images/product_details_img.jpg" width="537" height="856" alt=""></div>
          <div class="item"><img src="images/product_details_img.jpg" width="537" height="856" alt=""></div>
          <div class="item"><img src="images/product_details_img.jpg" width="537" height="856" alt=""></div>
        </div>
      </div>
      <div class="col-md-6 product_details_right">
        <h2 class=" pb-2"> Secret Oudh EDP (100ml)</h2>
        <div class="row">
          <div class="col-md-4 ">
            <div class="price_for_details">
              <div class="price_section text-left">£20.00</div>
            </div>
          </div>
          <div class="col-md-8 pt-3"> <img src="images/in_stock.png" alt="" width="103" height="18"> </div>
          <div class="col-md-12 product_feature mb-3 mt-3">
            <ul>
              <li class="product_feature_img"><img src="images/car_icon.png" alt="" width="31" height="21"></li>
              <li>Free UK next day delivery</li>
            </ul>
            <ul>
              <li class="product_feature_img"><img src="images/int_shopping.png" alt="" width="25" height="25"></li>
              <li>Safe international shipping</li>
            </ul>
            <ul>
              <li class="product_feature_img"><img src="images/return_icon.png" alt="" width="28" height="28"></li>
              <li>Easy returns</li>
            </ul>
            <ul>
              <li class="product_feature_img"><img src="images/secure_payment.png" alt="" width="21" height="28"></li>
              <li>Secure payments</li>
            </ul>
          </div>
          <div class="col-md-4">
            <div class="product-qty clearfix"> <span>
              <input type="button" class="qtyminus" value="-">
              <input type="text" class="form-control qty" placeholder="1" min="1" name="product_quantity" title="Qty" id="product_quantity" max="50" value="1">
              <input type="button" class="qtyplus" value="+">
              </span> </div>
          </div>
          <div class="col-md-4"> <a class="btn view_all" href="#"> Add to Basket </a> </div>
          <div class="col-md-4 heart_icon"><a href="#"><i class="fas fa-heart" aria-hidden="true"></i></a> </div>
          <div class="col-md-12 pt-2">
            <div class="bs-example w-100">
              <div class="accordion" id="accordionExample">
                <div class="card">
                  <div class="card-header" id="headingOne">
                    <h2 class="mb-0">
                      <button type="button" class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"><i class="fa fa-plus" aria-hidden="true"></i> Description</button>
                    </h2>
                  </div>
                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
                    <div class="card-body delivery_des">Secret Oud Private Edition by Oudh Al Anfar defines purity in Perfume production and the best delivery of Top-Notch fragrances. Anfar has continued its family legacy of offering a high-end and exclusive wide range of top quality Arabian and Oriental perfumes. With the recent launch of their new Private Edition fragrances, Anfar strongly stands in the market as an expert in tailoring the splendid array of Oudh perfumes to suit the taste of all their valued customers worldwide.<br/>
                      <br/>
                      Brand: Oudh Al Anfar <br/>
                      Fragrance Perfume: Secret Oud Private Edition<br/>
                      Fragrance Notes: Oriental<br/>
                      Top Notes: Rose, Floral vines, Peach, Mongolia<br/>
                      Middle Notes: wood, Oudh, Caramel, Agarwood<br/>
                      Base Notes: fruity flavours, patchouli, Iris vine<br/>
                      Perfume for: Men and Women<br/>
                      Size : 100 ml<br/>
                      Concentration: Eau De Perfume (EDP) </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header" id="headingOne1">
                    <h2 class="mb-0">
                      <button type="button" class="btn btn-link" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true"><i class="fa fa-plus" aria-hidden="true"></i> Additional Information</button>
                    </h2>
                  </div>
                  <div id="collapseOne1" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample" style="">
                    <div class="card-body delivery_des">
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header" id="headingFour">
                    <h2 class="mb-0">
                      <button type="button" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour"><i class="fa fa-plus" aria-hidden="true"></i> Shipping & Delivery</button>
                    </h2>
                  </div>
                  <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                    <div class="card-body delivery_des">
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="feature_collection pt-4 pb-4">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="header_section">
          <h2 class="text-center">You may also like</h2>
        </div>
      </div>
      <div id="owl-also_link" class="owl-carousel owl-theme">
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <div class="best_seller"><img src="images/best_seller.png" alt="" width="59" height="18"></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list1.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list2.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list3.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list4.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">223 Street Men EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£15.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <div class="best_seller"><img src="images/best_seller.png" alt="" width="59" height="18"></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list1.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list2.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list3.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="col-md-12">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" alt="" width="22" height="22"></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list4.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">223 Street Men EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£15.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include("footer.php"); ?>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script defer src="mobile_menu/js/script.js"></script>
<script src="owl-carousel/owl.carousel.js"></script>
<script type="text/javascript">
 $("#owl-new_arrival").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 2],
			[700, 2],
			[1000, 3],
			[1200,3],
			[1400, 3],
			[1600, 3]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	   $("#owl-best_seller").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 2],
			[700, 2],
			[1000, 3],
			[1200,3],
			[1400, 3],
			[1600, 3]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	   $("#owl-product_slider").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 1],
			[700, 1],
			[1000, 1],
			[1200,1],
			[1400, 1],
			[1600, 1]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
   </script>
<script type="text/javascript">
$("#owl-product_gallery").owlCarousel({
        navigation:true,
	 autoPlay : 4000,
	autoPlay : false,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 1],
			[700, 1],
			[1000, 1],
			[1200,1],
			[1400, 1],
			[1600, 1]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	  $("#owl-also_link").owlCarousel({
        navigation:true,
	 autoPlay : 4000,
	autoPlay : false,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 1],
			[700, 2],
			[1000, 4],
			[1200,5],
			[1400, 5],
			[1600, 5]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	</script>
<script>

    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
        	$(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });
    });
</script>
</html>
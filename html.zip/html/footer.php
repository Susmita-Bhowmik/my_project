<footer class="main-footer pt-4 mb-4 web_footer_section">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="footer1">
          <h3>Shop</h3>
          <ul>
            <li><a href="#">Spray Perfumes</a></li>
            <li><a href="#">Home Fragrance</a></li>
            <li><a href="#">Fragrance Oils</a></li>
            <li><a href="#">Wholesale Oil</a></li>
            <li><a href="#">Gift Sets</a></li>
            <li><a href="#">Car Air Freshner</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-4">
        <div class="footer1">
          <h3>Help</h3>
          <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">FAQ's</a></li>
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Al Anfar</a></li>
            <li><a href="#">Delivery and Returns</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Wholesale Options</a></li>
            <li><a href="#"> Contact Us</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-2">
        <div class="footer1 footer2">
          <h3>Office Details</h3>
          <ul>
            <li><strong>London Musk</strong><br>
              Chrisp Street Market<br/>
              17 Market Square<br/>
              London E14 6AQ<br/>
              United Kingdom </li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="footer1 footer2">
          <h3>Contact</h3>
          <ul>
            <li class="mb-2">
              <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><img src="images/icon_phone.png" alt="" width="35" height="35"></td>
                  <td><a href="#"> +44 7940 435546<br/>
                    +44 2033 021319</a></td>
                </tr>
              </table>
            </li>
            <li class="mb-2">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><img src="images/message_icon.png"  alt="" width="38" height="26"></td>
                  <td><a href="#">info@londonmusk.com<br/>
                    londonmuskltd@gmail.com</a></td>
                </tr>
              </table>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="footer_bottom_section">
    <div class="container">
      <div class="row">
        <div class="col-md-4 text-left bottom_text"> © londonmusk.com 2022 | ALL RIGHTS RESERVED </div>
        <div class="col-md-4 text-center"><img src="images/card.png" alt="" width="351" height="34"></div>
        <div class="col-md-4 text-right">
          <ul class="social_footer">
            <li><a href="#" target="_blank"><img src="images/facebook_icon.png" alt="" width="36" height="36"></a></li>
            <li><a href="#" target="_blank"><img src="images/instagram_icon.png" alt="" width="36" height="36"></a></li>
            <li><a href="#" target="_blank"><img src="images/twitter_icon.png" alt="" width="36" height="36"></a></li>
            <li><a href="#" target="_blank"><img src="images/pinterest.png" alt="" width="36" height="36"></a></li>
            <li><a href="#" target="_blank"><img src="images/youtube.png" alt="" width="36" height="36"></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
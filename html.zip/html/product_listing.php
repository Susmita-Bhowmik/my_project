<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>London Musk</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/cfe2f4d7d5.js" crossorigin="anonymous"></script>
<link href="owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="owl-carousel/owl.theme.css" rel="stylesheet">
<link href="owl-carousel/owl.transitions.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="mobile_menu/css/style_menu.css">
<link rel="stylesheet" type="text/css" href="mobile_menu/css/ionicon.min.css">
</head>
<body>
<?php include("header.php"); ?>
<section class="section sub_banner_section clearfix">
  <div class="container">
    <div class="row">
      <div class="col-md-12"> <a href="#">Home</a> / Spray Perfumes </div>
    </div>
  </div>
</section>
<section class="product_listing_section pt-2 pb-5">
  <div class="container">
    <div class="row">
      <!--<div class="col-md-3 product_listing_left">
        <div class="select_menu">
          <select name="slct" class="custom-select" id="sort_by_value" onchange="get_product(6)">
            <option value="">SORT BY :   BESTSELLERS</option>
            <option value="1">Featured</option>
            <option value="2">Price---Low to High</option>
            <option value="3">Price---High to Low</option>
            <option value="4">A-Z</option>
            <option value="5">Z-A</option>
            <option value="6">New In</option>
            <option value="7">Oldest</option>
          </select>
        </div>
        <nav class="nav1" role="navigation">
          <ul class="nav__list">
            <li>
              <input id="group-1" type="checkbox" hidden />
              <label for="group-1" class="main_cate"><span class="fa fa-angle-right"></span> <strong>Categories</strong></label>
              <ul class="group-list">
                <li>
                  <input id="sub-group-1" type="checkbox" hidden />
                  <label for="sub-group-1"><span class="fa fa-angle-right"></span>Spray Perfumes</label>
                  <ul class="sub-group-list">
                    <li><a href="#">Spray Perfumes 1</a></li>
                    <li><a href="#">Spray Perfumes 2</a></li>
                    <li><a href="#">Spray Perfumes 3</a></li>
                    <li><a href="#">Spray Perfumes 4</a></li>
                    <li><a href="#">Spray Perfumes 5</a></li>
                  </ul>
                </li>
                <li>
                  <input id="sub-group-2" type="checkbox" hidden />
                  <label for="sub-group-2">Fragrance Oils <div style="float:right; margin: 0;">250</div></label>
                </li>
                <li>
                  <input id="sub-group-3" type="checkbox" hidden />
                  <label for="sub-group-3">Gift Sets <div style="float:right; margin: 0;">150</div></label>
                </li>
                <li>
                  <input id="sub-group-4" type="checkbox" hidden />
                  <label for="sub-group-4">Car Air Freshner <div style="float:right; margin: 0;">90</div></label>
                </li>
                <li>
                  <input id="sub-group-5" type="checkbox" hidden />
                  <label for="sub-group-5">Home Fragrance <div style="float:right; margin: 0;">100</div></label>
                </li>
                <li>
                  <input id="sub-group-5" type="checkbox" hidden />
                  <label for="sub-group-5">Wholesale Oil <div style="float:right; margin: 0;">180</div></label>
                </li>
              </ul>
            </li>
            <li>
              <input id="group-2" type="checkbox" hidden />
              <label for="group-2" class="main_cate"><span class="fa fa-angle-right"></span> <strong>FRAGRANCE TYPE</strong></label>
              <ul class="group-list">
                <li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Floral <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Aromatic <div style="float:right; margin: 0;">8</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Floriental Gourmand <div style="float:right; margin: 0;">9</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Oriental <div style="float:right; margin: 0;">10</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Chypre <div style="float:right; margin: 0;">15</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Fresh Fougere <div style="float:right; margin: 0;">5</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Aquatic <div style="float:right; margin: 0;">12</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Energetic Woody Fruity <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Exotic Fruity Floral <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Floral Woody Musk <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Floral Oriental <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Woody Musk <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Rich White Floral <div style="float:right; margin: 0;">7</div></a></li>
                <li><a href="#">
                  <input name="" type="checkbox" value="" />
                  Fresh Woody Fougere <div style="float:right; margin: 0;">7</div></a></li>
              </ul>
            </li>
            <li>
              <input id="group-3" type="checkbox" hidden />
              <label for="group-3" class="main_cate"><span class="fa fa-angle-right"></span> <strong>BRAND NAME</strong></label>
              <ul class="group-list">
                <li>BRAND NAME here</li>
              </ul>
            </li>
            <li>
              <input id="group-4" type="checkbox" hidden />
              <label for="group-4" class="main_cate"><span class="fa fa-angle-right"></span> <strong>Price (£)</strong></label>
              <ul class="group-list">
                <li>Price here</li>
              </ul>
            </li>
            <li>
              <input id="group-5" type="checkbox" hidden />
              <label for="group-5" class="main_cate"><span class="fa fa-angle-right"></span> <strong>GENDER</strong></label>
              <ul class="group-list">
                <li>GENDER here</li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>-->
      <div class="col-md-12 product_listing_right">
      
      
      <div class="row">
      <div class="col-md-3 text-right">
      </div>
          <div class="col-md-6">
          <h2 class="text-center p-0 m-0 pb-3">Spray Perfumes</h2>
          </div>
          <div class="col-md-3 text-right">
          <div class="select_menu">
          <select name="slct" class="custom-select" id="sort_by_value" onchange="get_product(6)">
            <option value="">SORT BY :   BESTSELLERS</option>
            <option value="1">Featured</option>
            <option value="2">Price---Low to High</option>
            <option value="3">Price---High to Low</option>
            <option value="4">A-Z</option>
            <option value="5">Z-A</option>
            <option value="6">New In</option>
            <option value="7">Oldest</option>
          </select>
        </div>
          </div>
          </div>
      
      
        
        <div class="row">
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <div class="best_seller"><img src="images/best_seller.png" width="107" height="31" alt="" /></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list1.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Secret Oudh EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list2.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Saqr Al Khaleej EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div><div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list3.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Faris Al Sahra EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list4.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">223 Street Men EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£15.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list5.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Aitizaz Black Oud EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <div class="best_seller"><img src="images/best_seller.png" width="107" height="31" alt="" /></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list6.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Ancient Oud EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list7.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Dhahab Khusoosi EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list8.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Aitizaz Pure Sapphire</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list9.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Aneeq EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£15.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list10.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">AL Amrah EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="best_seller"><img src="images/best_seller.png" width="107" height="31" alt="" /></div>
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list11.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Areej Al Arab EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-3">
            <div class="product_box">
              <div class="wish_list"><a href="#"><img src="images/wishlist1.png" width="22" height="22" alt="" /></a></div>
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td class="product_box_img"><img src="images/product_list12.jpg" alt="" width="231" height="231"></td>
                  </tr>
                  <tr>
                    <td class="product_title">Gold Dollar EDP</td>
                  </tr>
                  <tr>
                    <td class="product_price">£20.00</td>
                  </tr>
                  <tr>
                    <td class="product_btn"><a href="#">Shop now</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-12 text-center mt-2"> <a href="#"><img src="images/load_more.jpg" width="121" height="31" alt="" /></a> </div>
        </div>
      </div>
    </div>
  </div>
</section>
</section>
<?php include("footer.php"); ?>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script defer src="mobile_menu/js/script.js"></script>
<script src="owl-carousel/owl.carousel.js"></script>
<script type="text/javascript">
 $("#owl-new_arrival").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 2],
			[700, 2],
			[1000, 3],
			[1200,3],
			[1400, 3],
			[1600, 3]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	   $("#owl-best_seller").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 2],
			[700, 2],
			[1000, 3],
			[1200,3],
			[1400, 3],
			[1600, 3]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
	  
	   $("#owl-product_slider").owlCarousel({
        navigation:true,
		autoPlay : true,
		 pagination:false,
		  itemsCustom : [
			[0, 1],
			[450, 1],
			[600, 1],
			[700, 1],
			[1000, 1],
			[1200,1],
			[1400, 1],
			[1600, 1]
		  ],
		  navigationText: [
		  "<i class='fa fa-chevron-left'></i>",
		  "<i class='fa fa-chevron-right'></i>"
		  ],
		   afterInit : function(elem){
          var that = this
          that.owlControls.prependTo(elem)
        }
      });
   </script>
<script>

    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
        	$(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });
    });
</script>
</html>
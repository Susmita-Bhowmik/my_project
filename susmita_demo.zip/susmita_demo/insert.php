<?php 

include 'dbcon.php';


$name 		= $_POST['name'];
$phone 		= $_POST['phone'];
$email 		= $_POST['email'];
$address 	= $_POST['address'];
$file 		= $_FILES['photo'];
$role 		= $_POST['role'];
$travel 	= $_POST['travel'];


$filename  = $file['name'];
$filepath  = $file['tmp_name'];
$fileerror  = $file['error'];

if($fileerror==0){
	$desfile = 'upload/'.$filename;
	move_uploaded_file($filepath, $desfile);
}




$sql 		= " INSERT INTO `registers`(`name`, `phone`, `email`, `address`, `photo`, `job_role`, `travel`) VALUES ('$name','$phone','$email','$address','$filename','$role','$travel')";




$result    = $con->query($sql);

if($result){
	echo 'inserted';
}



















 ?>
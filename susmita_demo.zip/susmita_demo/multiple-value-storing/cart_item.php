<?php 
error_reporting(0);
session_start();
$cart = $_SESSION['product_cart'];
// $action = $_POST['action'];
// $product_id = $_POST['product_id'];

// print_r($cart);
// Array ( [14] => Array ( [p_id] => 14 [title] => Color Chiffon Hijab [real_price] => 20.00 [quantity] => 2 )

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Product List</title>
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<table border="1">
    <th>Product Id</th>
    <th>Product name</th>
    <th>Product quantity</th>
    <th>Product Price</th>
	<th>Total</th>
	<th>product image</th>
	<th>Remove Item</th>

    <?php 
	//$total_price=0;
	foreach ($cart as $key => $value) {
    	 $product_image = explode("," ,$value['image']);
    	$quantity = intval($value['quantity']);
    	$item_price = $quantity * $value['real_price'];
		//$total_price = $total_price + ($quantity * $value['real_price']);
$product_id = $value['p_id'];
    	?>

<tr>
	<td><?php
	
	  echo $product_id; ?></td>
	<td><?php echo $value['title']; ?></td>
	
	<td><input type="hidden" class="cart_product_id" value="<?php echo $product_id; ?>">
		<input type="number" id="quantity<?php echo $product_id; ?>"  value="<?php echo $quantity; ?>"></td>
        <td>

		<?php echo $value['real_price']; ?>
			
		</td>
	<td><?php echo $item_price; ?></td>
	<?php  

		     for($i=0;$i<count($product_image)-1;$i++) { 
		     	}	 // echo  $product_image[$i];
		     	?> 
			<td><img src="upload/<?php echo $product_image[0];?>"></td>
	<td><button onclick="myfunction(<?php echo $product_id; ?>)">Remove Item</button></td>
	


</tr>



   <?php 	
    } 

?>






</table><br><br>
<button   onclick="update_quantity()" name="quantity">Update</button>

<?php include 'footer.php'; ?>

<style type="text/css">
 img{
    height: 200px;
    width: 150px;
}
  }
</style>
</body>
</html>
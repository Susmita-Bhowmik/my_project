<?php 
session_start();
include 'dbcon.php';
 $action = $_POST['action'];
 $product_id = $_POST['product_id'];
 
 if($action=="add")
{
	$quantity = $_POST['quantity'];
	 if(!empty($product_id)){
		 $query = mysqli_query($con,"select * from products where id = '".$product_id."'");
		 $rs = mysqli_fetch_array($query);
		 
		 $product = array("p_id"=>$product_id,"title"=>$rs['name'],"real_price"=>$rs['price'],"details"=>$rs['details'],"image"=>$rs['image'],"quantity"=>$quantity);
		if(isset($_SESSION['product_cart']) && !empty($_SESSION['product_cart']))
		{
			if(!array_key_exists($rs['id'],$_SESSION['product_cart']))
			{
				$_SESSION['product_cart'][$rs['id']] = $product;
			}
			else{
				$_SESSION['product_cart'][$rs['id']]['real_price'] = $_SESSION['product_cart'][$rs['id']]['real_price'];
				$_SESSION['product_cart'][$rs['id']]['quantity'] = $_SESSION['product_cart'][$rs['id']]['quantity']+$quantity;
			    }		
		}
		else{
		  $_SESSION['product_cart'][$rs['id']] = $product;
		}
	}	
}
if($action=="remove"){
	unset($_SESSION["product_cart"][$product_id]);	
}

if($action=="update"){
	$quantity = $_POST['quantity'];
if(isset($_SESSION['product_cart']) && !empty($_SESSION['product_cart']))
		{
			if(!array_key_exists($product_id,$_SESSION['product_cart']))
			{
				$_SESSION['product_cart'][$product_id] = $product;
			}
			else{
				$_SESSION['product_cart'][$product_id]['quantity'] = $quantity;
			    }		
		}
		else{
		  $_SESSION['product_cart'][$rs['id']] = $product;
		}
}
 



print_r($_SESSION['product_cart']);
?>

	
	

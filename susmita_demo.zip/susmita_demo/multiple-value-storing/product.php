<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Product</title>
</head>
<body>

	<table border="1">
		
		<th>Product name</th>
		<th>Product details</th>
		<th>Product Price</th>
		<th>product image</th>
		<th>Action</th>
			
		
<?php 

include 'dbcon.php';
$sql = "SELECT * FROM products";
 $result = mysqli_query($con,$sql);
         if($result->num_rows > 0) 
       {
       
        while($row = $result->fetch_assoc())
        {
       

         // $category        = explode(" ", $row['category_name']);
        	//$category    = unserialize($row['category_name']);
			//print_r($category);
        	// foreach ($category as $key => $value) {
	        //  echo $value.",";

        $product_name    = $row['name'];
        $product_price   = $row['price'];
        $product_details = $row['details'];
   
        $product_image = explode("," ,$row['image']);
         $category_id = explode("," ,$row['category_id']);

 ?>
<tr>	
			<td><?php echo $product_name ;?></td>
			<td><?php echo $product_details ;?></td>
			<td><?php echo $product_price ;?></td>
 
		<?php  

		     for($i=0;$i<count($product_image)-1;$i++) { 
		     	}	 // echo  $product_image[$i];
		     	?> 
			<td><img src="upload/<?php echo $product_image[0];?>"></td>

<?php 
			for($j=0;$j<count($category_id);$j++) { 
		     		  }?>
		     		 <td><a href="view_product.php?category_id=<?php echo $category_id[1];?>">View</a></td></tr>

		     		
<?php		     	

}
}
?>




	

<style type="text/css">
 img{
    height: 200px;
    width: 150px;
}
  }
</style>
  </table>
</body>
</html>
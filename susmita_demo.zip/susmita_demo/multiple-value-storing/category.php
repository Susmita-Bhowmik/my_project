
<?php  
include 'dbcon.php';

if(isset($_POST['submit'])){
$category      = $_POST['add_to_category'];
$result = mysqli_query($con,"INSERT INTO categories(category_name) VALUES ('$category')");
if($result){

 $query  = "SELECT * FROM categories";
          $result = mysqli_query($con,"SELECT * FROM categories");
         if($result->num_rows > 0) 
       {
       
        while($row = $result->fetch_assoc())
        {
        ?>
        	  <ul class="group-list">
				<li>
					<?php echo  $row['category_name'];?>
                </li>
                
         
         </ul>

<?php
          }
        }



	?>
<?php	
}}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Category</title>
</head>
<body>
	<form method="post">
              <input type="text" name="add_to_category"><br><br>
              <button type="submit" name="submit">Add to category</button>
              </form>

</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script type="text/javascript">
function form_submit(product_id){
//alert(product_id);
		$.ajax({
		type: 'post',
		url: 'add_to_cart.php',
		data:{action:'add',product_id:product_id,quantity:1},
		success:function(result){
		// alert(result);
		alert("Product successfully added to your cart.");
	     // var currentURL = window.location.href;
	     // window.location = currentURL;
        window.location.href = "cart_item.php";
		}
		
		});


}
	 
</script>
<script type="text/javascript">
	
	function myfunction(product_id){

		$.ajax({
		type: 'post',
		url: 'add_to_cart.php',
		data:{action:'remove',product_id:product_id},
		success:function(result){
		 // alert(result);
		alert("Product successfully removed!");
	     // var currentURL = window.location.href;
	     // window.location = currentURL;
      //   window.location.href = "cart_item.php";
		}
		
		});
		
	console.log(p_id);
	alert(result);
	}
</script>
<script type="text/javascript">
	function update_quantity(){
		var elements = document.querySelectorAll('.cart_product_id');
for (var i = 0; i < elements.length; i++) {
  //alert(elements[i].value);
  var ppp_id= elements[i].value;
  
  var quantity = document.getElementById("quantity"+ppp_id).value;
		$.ajax({
		type: 'post',
		url: 'add_to_cart.php',
		data:{action:'update',quantity:quantity,product_id:ppp_id},
		success:function(result){
		  //alert(result);
		
	      var currentURL = window.location.href;
	      window.location = currentURL;
        // window.location.href = "cart_item.php";
		}
		
		});
}
		
		
	}
</script>
</body>
</html>
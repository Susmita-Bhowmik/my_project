<?php 
include 'dbcon.php';
if(isset($_POST['submit'])){
$new_category=$new_file ="";
$product_name    = $_POST['product_name'];
$product_price   = $_POST['product_price'];
$product_datails = $_POST['product_datails']; 
//
$category        = $_POST['p-category'];
$new_category    .= implode(',' , $category);
// echo $new_category;
 

$file           = $_FILES['image_product']['name'];
$file_count     = count($file);

for($i=0;$i<$file_count;$i++){


$filename       = $_FILES['image_product']['name'][$i];
$filepath       = $_FILES['image_product']['tmp_name'][$i];
$fileerror      = $_FILES['image_product']['error'][$i];


if($fileerror==0){
  $desfile = 'upload/'.$filename;
  move_uploaded_file($filepath, $desfile);
    $new_file .= $filename.","; 
// " ".$filename.","; 
}}
// echo $new_file;
// echo "INSERT INTO products(name,price,details,image,category_id) 
//   VALUES ('$product_name','$product_price','$product_datails','$new_file','$new_category')";
//   die;

$result = mysqli_query($con,"INSERT INTO products(name,price,details,image,category_id) 
  VALUES ('$product_name','$product_price','$product_datails','$new_file','$new_category')");



if($result ){
  echo 'inserted';
 // header('product.php');
}




// $result1 = mysqli_query($con,"INSERT INTO categories(category_name) VALUES ('$category')");


}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Product Listing</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/cfe2f4d7d5.js" crossorigin="anonymous"></script>
	<link href="owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="owl-carousel/owl.theme.css" rel="stylesheet">
	<link href="owl-carousel/owl.transitions.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="mobile_menu/css/style_menu.css">
	<link rel="stylesheet" type="text/css" href="mobile_menu/css/ionicon.min.css">
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	</head>
<body>
  <form method="post"  enctype= "multipart/form-data">
  <div class="main">
    <div class="container">
      <div class="row">
      <div class="col-md-2">
        <label for="group-2" class="main_cate"><span class="fa fa-angle-right"></span><u> Product Name</u></label>
        <input type="text" name="product_name" value="Color  Chiffon Hijab" ><br> 
      </div>
      <div class="col-md-2">
        <label for="group-2" class="main_cate"><span class="fa fa-angle-right"></span><u> Product price</u></label>
        <input type="text" name="product_price" value="20.00" ><br>
      </div>
      <div class="col-md-2"> <label for="group-2" class="main_cate"><span class="fa fa-angle-right"></span><u> Product Details</u></label><input type="text" name="product_datails" value="" > 
      </div>
      <div class="col-md-2"><label for="group-2" class="main_cate"><span class="fa fa-angle-right"></span><u> Product Category</u></label>
 <?php 
// if(isset($_POST['submit'])){
// $category      = $_POST['add_to_category'];
// $result = mysqli_query($con,"INSERT INTO categories(category_name) VALUES ('$category')");
// if($result){

 $query  = "SELECT * FROM categories";
          $result = mysqli_query($con,"SELECT * FROM categories");
         if($result->num_rows > 0) 
       {
       
        while($row = $result->fetch_assoc())
        {
        ?>
            <ul class="group-list">
        <li>

          <input type="checkbox" name="p-category[]" value="<?php echo $row['id']; ?>"><?php echo $row['category_name']; ?>

                </li>
                
         
         </ul>

<?php
          }
        }


  
  ?>
<?php 



?>
  <!-- <input type="button" name="" id="btn" onclick = " return Openform();" value="Add to category"> -->
                

               <script type="text/javascript">
                 function Openform(){
                
                 window.location.href = 'category.php';
                 }
                
              </script>
              
        
      </div>

      <div class="col-md-2"><label for="group-2" class="main_cate"><span class="fa fa-angle-right"></span><u> Product image</u></label>
      <input type="file" name="image_product[]" multiple><img src="images/product_list_img4.jpg"> 
      </div>
      <div class="col-md-2">
      
      </div>
      <div class="btn">
      <button type="submit" name="submit">Set Product</button></div>

</div>
</div>
</div>
</form>


<style type="text/css">
  .btn{
    margin-left: 452px;
    margin-top: 63px;
}
  }
</style>
</body>
</html>
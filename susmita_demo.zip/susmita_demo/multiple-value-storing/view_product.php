<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Product List</title>
</head>

<body>

<table border="1">
  
    <th>Product name</th>
    <th>Product details</th>
    <th>Product Price</th>
    <th>product image</th>
   
<?php 
error_reporting(0);
session_start();
// session_destroy();
// print_r($_SESSION['product_cart']);
include 'dbcon.php';
$category_id = $_GET['category_id'];

$result  = mysqli_query($con,"SELECT * FROM products WHERE FIND_IN_SET('$category_id',category_id)");

  if($result->num_rows > 0) 
       {
      
        while($row = $result->fetch_assoc())
        {
        
        	
        $product_id	= $row['id'];
        $product_name    = $row['name'];
        $product_price   = $row['price'];
        $product_details = $row['details'];
        $product_image = explode("," ,$row['image']);

 ?>
    <?php
 ?>
  <tr>
    <?php
        $id = $product_id;
        ?>
    <td id="product_name"><?php echo $product_name ;?></td>
    <td><?php echo $product_details ;?></td>
    <td><?php echo $product_price ;?></td>
    <td><?php  

		     for($i=0;$i<count($product_image)-1;$i++) { 
		     		  // echo  $product_image[$i];
		     	?>
      <img src="upload/<?php echo $product_image[0];?>">
      <?php }?></td>
    <td><button type="button" id="btn_submit" onclick="form_submit(<?php echo $id;?>)" >Add to cart</button></td>
  </tr>
  <?php		     	

}
}
?>
  <style type="text/css">
 img{
    height: 200px;
    width: 150px;
}

</style>
</table>
<?php include 'footer.php'; ?>
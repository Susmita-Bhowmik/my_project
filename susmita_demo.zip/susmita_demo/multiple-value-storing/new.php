

 $_SESSION['product_id'] = $_POST['product_id'];
$product_id = $_SESSION['product_id'];
$result  = mysqli_query($con,"SELECT * FROM products WHERE id = '$product_id' ");

// echo $_SESSION['product_id'];
if($result->num_rows > 0) 
       {
       
        while($row = $result->fetch_assoc())
        {
        	$_SESSION['product_name'] = $row['name'];
        	$_SESSION['product_price'] = $row['price'];
        	$_SESSION['product_details'] = $row['details'];
        	$_SESSION['product_image'] = explode("," ,$row['image']);


?>
<div id="shopping-cart">
<div class="txt-heading text-center">Shopping Cart</div>
<table border="1">

 	   <th>Product name</th>
		<th>Product details</th>
		<th>Product Price</th>
		<th>product image</th>

		<tr><td><?php echo $product_name ;?></td>
			<td><?php echo $product_details ;?></td>
			<td><?php echo $product_price ;?></td>
			<?php  

		     for($i=0;$i<count($_SESSION['product_image'])-1;$i++) { 
		     		} // echo  $product_image[$i];
		     	?> 
			<td><img src="upload/<?php echo $_SESSION['product_image'][0];?>"></td>
			
		</tr>
		<?php 

		}
}

		?>
</table>
<style type="text/css">
 img{
    height: 200px;
    width: 150px;
}
  }
</style>
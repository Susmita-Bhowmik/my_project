<?php 
session_start();
session_unset();
session_destroy();




?>
<script type="text/javascript">
	alert('item removed!');
	window.location.href = "view_product.php";
</script>
<?php 
include 'dbcon.php';


$product_name 	 = $_POST['product_name'];
$product_price   = $_POST['product_price'];
$product_datails = $_POST['product_datails']; 
$men 			= serialize($_POST['mens']);
$women 			= serialize($_POST['womens']);
$kids 			= serialize($_POST['kids']);
$misc 			= serialize($_POST['misc']);
$file  			= $_FILES['image_product'];
$filename       = $file['name'];
$filepath       = $file['tmp_name'];
$fileerror      = $file['error'];


if($fileerror==0){
	$desfile = 'upload/'.$filename;
	move_uploaded_file($filepath, $desfile);
}
echo $desfile;


$sql = "INSERT INTO categories( name, price, details, mens, womens, kids, misc, image) VALUES ('$product_name','$product_price','$product_datails','$men','$women','$kids','$misc','$filename')";
echo $sql;

$result =mysqli_query($con,$sql);
echo $result;
if($result){
	echo 'inserted';
}


?>
 <?php  

		     for($i=0;$i<count($product_image)-1;$i++) { 
		     		 // echo  $product_image[$i];
		     	?> 
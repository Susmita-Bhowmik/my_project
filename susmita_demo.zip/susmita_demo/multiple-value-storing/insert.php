<?php 
include 'dbcon.php';
if(isset($_POST['submit'])){

$product_name 	 = $_POST['product_name'];
$product_price   = $_POST['product_price'];
$product_datails = $_POST['product_datails']; 
$men 			= serialize($_POST['mens']);
$women 			= serialize($_POST['womens']);
$kids 			= serialize($_POST['kids']);
$misc 			= serialize($_POST['misc']);
$file  			= $_FILES['image_product'];
$filename       = $file['name'];
$filepath       = $file['tmp_name'];
$fileerror      = $file['error'];


if($fileerror==0){
	$desfile = 'upload/'.$filename;
	move_uploaded_file($filepath, $desfile);
}



$sql = "INSERT INTO categories( name, price, mens, womens, kids, misc, image) VALUES ('$product_name','$product_price','$men','$women','$kids','$misc','$filename')";


$result =mysqli_query($con,$sql);

if($result){
	echo 'inserted';
}}









?>
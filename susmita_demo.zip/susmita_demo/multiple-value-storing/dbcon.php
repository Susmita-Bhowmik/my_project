<?php
$con = new mysqli('localhost','root','','susmita_demo');
if(!$con){
	echo 'failed!';
}


 ?>
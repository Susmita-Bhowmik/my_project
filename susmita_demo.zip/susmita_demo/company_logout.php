<?php 
session_start();
$_SESSION["company_id"] = "";
$_SESSION["username"] = "";
$_SESSION["profile_pic"] = "";
$_SESSION["phone"] = "";
if($_SESSION["company_id"]=="")
{
	 ?>
  <script type="text/javascript">
    alert("logout");
    window.location="company_login.php";

  </script>
  <?php
}
?>
<?php error_reporting(0);

session_start();
include ('dbcon.php');
include 'header.php'; 
?>

<section class="section d-flex full-height justify-content-center align-items-center">
 
 <div class="login-wrap w-100 m-auto clearfix">
  <div class="login-box w-100 clearfix">
   <div class="login-logo"><a href="#"><img src="images/logo.png" alt="Logo" class="img-fluid"></a></div>
   <div class="section-title text-center clearfix">
    <h2 class="heading">Welcome Back!</h2>
    <span class="sub-heading">Login to continue</span>
   </div>
   <div class="form-section pt-4 clearfix">
    <script type="text/javascript">
        
        function login_form()
        {
var email_address= document.getElementById("email_address").value;
if(email_address=="")
{
alert("Please enter email address.");
document.getElementById("email_address").focus();
return false;
}
var worker_email = document.getElementById('email_address');
   var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
   if (!filter.test(worker_email.value))
   {
     alert('Please enter a valid email id.');
    document.getElementById('email_address').focus();
    return false;
   }

   var password= document.getElementById("password").value;
if(password=="")
{
alert("Please enter a valid password.");
document.getElementById("password").focus();
return false;
}
        }

    </script>


<?php 
if(isset($_POST['btn_submit']))
{
  $email_address     = $_POST['email_address'];
  $password    = $_POST['password'];


$sql = mysqli_query($con,"SELECT * FROM `registers` WHERE `email`='$email_address' AND `password`='".md5($password)."'");
$rowcount  =  mysqli_num_rows($sql);
if($rowcount>0)
{
while($login_fetch = mysqli_fetch_array($sql))
{
$_SESSION["user_id"] = $login_fetch['id'];
$_SESSION["user_name"] = $login_fetch['name'];
$_SESSION["user_email"] = $login_fetch['email'];
$_SESSION["profile_pic"] = $login_fetch['photo'];


$id =  $login_fetch['id'];
$name = $login_fetch['name'];
}
    
}

}
?>



    <form action="" method="post" onsubmit="return login_form()">
     <div class="form-floating mb-4">
      <input type="text" class="form-control" placeholder="" name="email_address" id="email_address" value="<?php echo $_SESSION["user_name"]; ?>">
      <label for="email_address">
      <i class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M256,0c-74.439,0-135,60.561-135,135s60.561,135,135,135s135-60.561,135-135S330.439,0,256,0z" fill="#8b8b8b" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M423.966,358.195C387.006,320.667,338.009,300,286,300h-60c-52.008,0-101.006,20.667-137.966,58.195    C51.255,395.539,31,444.833,31,497c0,8.284,6.716,15,15,15h420c8.284,0,15-6.716,15-15    C481,444.833,460.745,395.539,423.966,358.195z" fill="#8b8b8b" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg></i>
      Enter Username
      </label>	
     </div>
     <div class="form-floating mb-4">
      <input type="text" class="form-control" placeholder="" name="password" id="password" value="<?php echo $name; ?>">
      <label for="password">
      <i class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path xmlns="http://www.w3.org/2000/svg" d="m18.75 9h-.75v-3c0-3.309-2.691-6-6-6s-6 2.691-6 6v3h-.75c-1.24 0-2.25 1.009-2.25 2.25v10.5c0 1.241 1.01 2.25 2.25 2.25h13.5c1.24 0 2.25-1.009 2.25-2.25v-10.5c0-1.241-1.01-2.25-2.25-2.25zm-10.75-3c0-2.206 1.794-4 4-4s4 1.794 4 4v3h-8zm5 10.722v2.278c0 .552-.447 1-1 1s-1-.448-1-1v-2.278c-.595-.347-1-.985-1-1.722 0-1.103.897-2 2-2s2 .897 2 2c0 .737-.405 1.375-1 1.722z" fill="#8b8b8b" data-original="#000000" class=""></path></g></svg></i>
      Enter Password
      </label>	
     </div>
    <input type="submit" name="btn_submit" class="w-100 btn btn-lg custom-btn mb-3" value="Login">
    </form>
   </div>
   <div class="d-lg-flex form-bottom">
    <span class="w-50 text-lg-start"><a href="#" class="text-dark fw-semibold">Forget Password?</a></span>
    <span class="w-50 text-lg-end">New User? <a href="registration.php" class="text-dark fw-semibold">Register</a></span>
   </div>
   
   
  </div>
 </div>

</section>

<?php 
include("footer.php");
?>

<?php 

global $con;
$con = mysqli_connect('localhost','root','','susmita_demo');

if(!$con)
{
	echo "connection failed!";
}




?>
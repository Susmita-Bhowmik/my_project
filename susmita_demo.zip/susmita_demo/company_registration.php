<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>E Services</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Mulish:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<link rel="stylesheet" href="css/animate.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/media.css" rel="stylesheet">
</head>
<body>
<section class="section d-flex full-height justify-content-center align-items-center">
  <div class="login-wrap registration-box w-100 m-auto clearfix">
    <div class="login-box w-100 clearfix">
      <div class="login-logo"><a href="#"><img src="images/logo.png" alt="Logo" class="img-fluid"></a></div>
      <div class="section-title text-center clearfix">
        <h2 class="heading">Register to Eservices</h2>
        <span class="sub-heading">Create an Account</span> </div>
      <div class="form-section pt-4 clearfix">

<script>
   
   function form_submit()
  {
    var name= document.getElementById("inputName").value;
    if(name=="")
{
alert("Please enter a name!");
document.getElementById("inputName").focus();
return false;

}

var phone= document.getElementById("inputPhone").value;
    if(phone=="" || phone.length!=10)
{
alert("Please a valid the phone number!");
document.getElementById("inputPhone").focus();
return false;

}

var email= document.getElementById("inputEmail").value;
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if(email=="" || !filter.test(email))
{
alert("Please enter a valid email!");
document.getElementById("inputEmail").focus();
return false;

}


var address= document.getElementById("inputAddress").value;
    if(address=="")
{
alert("Please enter address");
document.getElementById("inputAddress").focus();
return false;

}

var photo= document.getElementById("formFile").value;
    if(photo=="")
{
alert("Please upload a photo!");
document.getElementById("formFile").focus();
return false;

}

var job_role = document.getElementById('job_role').value;
if(job_role=="")
{
  alert('Select a job role.');
  document.getElementById('job_role').focus();
  return false;
}

var travel = document.getElementById('travel').value;
if(travel=="")
{
  alert('Select a  travel.');
  document.getElementById('travel').focus();
  return false;
}


}


</script>

<?php

include 'connection.php';
if(isset($_POST['submit'])){

$name     = $_POST['name'];
$phone    = $_POST['phone'];
$email    = $_POST['email'];
$address  = $_POST['address'];
$role     = $_POST['role'];
$travel   = $_POST['travel'];
$password = md5(rand(10,10000));
$pre_password = rand(10,10000);


if($_FILES['photo']['name'])
    {
    $profile_photo=  time() . '_' . $_FILES['photo']['name'];
    }
    else
    {
      $profile_photo="";
    }
    $file_tmp =$_FILES['photo']['tmp_name'];
    move_uploaded_file($file_tmp,"upload/".$profile_photo);



     $fetch = mysqli_query($con,"SELECT * FROM registers WHERE email = '$email' AND phone = '$phone' ");
      if(mysqli_num_rows($fetch)!=0){
         
          

           ?>

  <script>
       alert('This email Or Phone Number is  already existed!');
   </script>

<?php
      }
      else{

        $sql    = " INSERT INTO `registers`(`name`, `phone`, `email`, `address`, `photo`, `job_role`, `travel`,`password`,`pre_password`) VALUES ('$name','$phone','$email','$address','$profile_photo','$role','$travel','$password','$pre_password')";




$result    = $con->query($sql);

if($result){
?>
<script>
  alert('Data inserted succesfully!');


</script>


<?php  
}

}
 }

 ?>
<form method="post"  enctype="multipart/form-data" onsubmit="return form_submit()">
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputName" name="name" placeholder="">
                <label for="inputText">Name</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="tel" class="form-control" id="inputPhone" name="phone" placeholder="">
                <label for="inputPhone">Phone</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputEmail" name="email" placeholder="">
                <label for="inputText">Email</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputAddress" name="address" placeholder="">
                <label for="inputAddress">Address</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <label for="formFile" class="form-label">Proof to work photo (Passport or NI)</label>
              <input class="form-control" type="file" id="formFile" name="photo">
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <select class="form-select" id="job_role" aria-label="Floating label select example" name="role">
                  <option selected>Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="floatingSelectGrid">Job role</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <select class="form-select" id="travel" aria-label="Floating label select example" name="travel">
                  <option selected>Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="floatingSelectGrid2">Travel for work</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="gridCheck1">
                <label class="form-check-label" for="gridCheck1"> I agree to the terms and conditions as set out by the user agreement.</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <input type="submit" class="w-100 btn btn-lg custom-btn mb-3" name="submit" value="Create an Account">
            </div>
          </div>
          
        </form>
      </div>
      <div class="d-lg-flex form-bottom"> <span class="w-100 text-center">Already a Member? <a href="company_login.php" class="text-dark fw-semibold">Sign in</a></span> </div>
    </div>
  </div>
</section>






<!-- jQuery --> 
<script src="js/jquery.min.js"></script> 
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script> 
<script>







$(document).ready(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
$(window).resize(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
</script>
<script>
var newClass = window.location.href;
newClass = newClass.substring(newClass.lastIndexOf('/')+1, 5);
$('body').addClass('overflow-hidden');
</script>
</body>
</html>

<?php 
include ('dbcon.php');
include 'header.php'; ?>


<section class="section d-flex full-height justify-content-center align-items-center">
  <div class="login-wrap registration-box w-100 m-auto clearfix">
    <div class="login-box w-100 clearfix">
      <div class="login-logo"><a href="#"><img src="images/logo.png" alt="Logo" class="img-fluid"></a></div>
      <div class="section-title text-center clearfix">
        <h2 class="heading">Register to Eservices</h2>
        <span class="sub-heading">Create an Account</span> </div>
      <div class="form-section pt-4 clearfix">
<script>
  function form_submit()
  {
    var contact_name= document.getElementById("contact_name").value;
    if(contact_name=="")
{
alert("Please enter name.");
document.getElementById("contact_name").focus();
return false;

}

var phone= document.getElementById("phone").value;
if(phone=="" || phone.length !== 10)
{
alert("Please enter a valid phone.");
document.getElementById("phone").focus();
return false;

}


var email_address= document.getElementById("email_address").value;
if(email_address=="")
{
alert("Please enter email address.");
document.getElementById("email_address").focus();
return false;
}
var worker_email = document.getElementById('email_address');
   var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
   if (!filter.test(worker_email.value))
   {
     alert('Please enter a valid email id.');
    document.getElementById('email_address').focus();
    return false;
   }

var address= document.getElementById("address").value;
if(address=="")
{
alert("Please enter address.");
document.getElementById("address").focus();
return false;

}
var upload_photo= document.getElementById("upload_photo").value;
if(upload_photo=="")
{
alert("Please upload photo.");
document.getElementById("upload_photo").focus();
return false;

}
var job_role= document.getElementById("job_role").value;
if(job_role=="")
{
alert("Please select role.");
document.getElementById("job_role").focus();
return false;

}
var travel= document.getElementById("travel").value;
if(travel=="")
{
alert("Please select travel.");
document.getElementById("travel").focus();
return false;

}

  }

</script>
<?php 
if(isset($_POST['btn_submit']))
{
$name     = $_POST['name'];
$phone    = $_POST['phone'];
$email    = $_POST['email'];
$address  = $_POST['address'];
$role     = $_POST['role'];
$travel   = $_POST['travel'];

$password= rand(10,10000);

if($_FILES['photo']['name'])
    {
    $profile_photo=  time() . '_' . $_FILES['photo']['name'];
    }
    else
    {
      $profile_photo="";
    }
    $file_tmp =$_FILES['photo']['tmp_name'];
    move_uploaded_file($file_tmp,"upload/".$profile_photo);

$ss= mysqli_query($con,"SELECT * FROM `registers` WHERE `email`='$email'");
$rowcount=mysqli_num_rows($ss);
if($rowcount==0)
{
    $sql = mysqli_query($con,"INSERT INTO `registers`(`name`, `phone`, `email`, `address`, `photo`, `job_role`, `travel`, `password`, `pre_password`) VALUES ('$name','$phone','$email','$address','$profile_photo','$role','$travel','".md5($password)."','$password')");
if($sql)
{
  ?>
  <script type="text/javascript">
    alert("You are successfully registered!");

  </script>
  <?php

}
else
{
  ?>
  <script type="text/javascript">
    alert("not inserted");

  </script>
  <?php

}
}
else
{
  ?>
  <script type="text/javascript">
    alert("email id already existed.");

  </script>
  <?php
}

}
?>


        <form method="post"  enctype="multipart/form-data" onsubmit="return form_submit()">
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="contact_name" placeholder="" name="name">
                <label for="contact_name">Name</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="tel" class="form-control" id="phone" placeholder="" name="phone">
                <p id="phone_text"></p>
                <label for="phone">Phone</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="email_address" placeholder="" name="email">
                <label for="email_address">Email</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="text" class="form-control" id="address" placeholder="" name="address">
                <label for="address">Address</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <label for="upload_photo" class="form-label">Proof to work photo (Passport or NI)</label>
              <input class="form-control" type="file" id="upload_photo" name="photo">
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <select class="form-select" id="job_role" aria-label="Floating label select example " name="role">
                  <option value="">Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="job_role">Job role</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <select class="form-select" id="travel" aria-label="Floating label select example" name="travel">
                  <option value="">Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="travel">Travel for work</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="gridCheck1">
                <label class="form-check-label" for="gridCheck1"> I agree to the terms and conditions as set out by the user agreement.</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <input type="submit" name="btn_submit" class="w-100 btn btn-lg custom-btn mb-3" value="Create an Account"  >
            </div>
          </div>
          
        </form>
      </div>
      <p style="color: green;"  class="text-center" id="msg"></p>
      <div class="d-lg-flex form-bottom"> <span class="w-100 text-center">Already a Member? <a href="login.php" class="text-dark fw-semibold">Sign in</a></span> </div>
    </div>
  </div>
</section>
<?php include 'footer.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>E Services</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Mulish:wght@300;400;500;600;700&display=swap" rel="stylesheet"> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<link rel="stylesheet" href="css/animate.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/media.css" rel="stylesheet">
</head>
<body>

<section class="section d-flex full-height justify-content-center align-items-center">
 
 <div class="login-wrap w-100 m-auto clearfix">
  <div class="login-box w-100 clearfix">
   <div class="login-logo"><a href="#"><img src="images/logo.png" alt="Logo" class="img-fluid"></a></div>
   <div class="section-title text-center clearfix">
    <h2 class="heading">Welcome Back!</h2>
    <span class="sub-heading">Login to continue</span>
   </div>
   <div class="form-section pt-4 clearfix">
    <form action="#" method="post">
     <div class="form-floating mb-4">
      <input type="text" class="form-control" placeholder="" id="floatingInput">
      <label for="floatingInput">
      <i class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M256,0c-74.439,0-135,60.561-135,135s60.561,135,135,135s135-60.561,135-135S330.439,0,256,0z" fill="#8b8b8b" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M423.966,358.195C387.006,320.667,338.009,300,286,300h-60c-52.008,0-101.006,20.667-137.966,58.195    C51.255,395.539,31,444.833,31,497c0,8.284,6.716,15,15,15h420c8.284,0,15-6.716,15-15    C481,444.833,460.745,395.539,423.966,358.195z" fill="#8b8b8b" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg></i>
      Enter Username
      </label>	
     </div>
     <div class="form-floating mb-4">
      <input type="password" class="form-control" placeholder="" id="floatingPassword">
      <label for="floatingPassword">
      <i class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path xmlns="http://www.w3.org/2000/svg" d="m18.75 9h-.75v-3c0-3.309-2.691-6-6-6s-6 2.691-6 6v3h-.75c-1.24 0-2.25 1.009-2.25 2.25v10.5c0 1.241 1.01 2.25 2.25 2.25h13.5c1.24 0 2.25-1.009 2.25-2.25v-10.5c0-1.241-1.01-2.25-2.25-2.25zm-10.75-3c0-2.206 1.794-4 4-4s4 1.794 4 4v3h-8zm5 10.722v2.278c0 .552-.447 1-1 1s-1-.448-1-1v-2.278c-.595-.347-1-.985-1-1.722 0-1.103.897-2 2-2s2 .897 2 2c0 .737-.405 1.375-1 1.722z" fill="#8b8b8b" data-original="#000000" class=""></path></g></svg></i>
      Enter Password
      </label>	
     </div>
    <input type="submit" class="w-100 btn btn-lg custom-btn mb-3" value="Login">
    </form>
   </div>
   <div class="d-lg-flex form-bottom">
    <span class="w-50 text-lg-start"><a href="#" class="text-dark fw-semibold">Forget Password?</a></span>
    <span class="w-50 text-lg-end">New User? <a href="#" class="text-dark fw-semibold">Register</a></span>
   </div>
   
   
  </div>
 </div>

</section>




<!-- jQuery -->
<script src="js/jquery.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
$(window).resize(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
</script>

<script>
var newClass = window.location.href;
newClass = newClass.substring(newClass.lastIndexOf('/')+1, 5);
$('body').addClass('overflow-hidden');
</script>

</body>
</html>

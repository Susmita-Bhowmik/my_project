<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>E Services</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Mulish:wght@300;400;500;600;700&display=swap" rel="stylesheet"> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<link rel="stylesheet" href="css/animate.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/media.css" rel="stylesheet">
</head>
<body>

<section class="section py-4">
 <div class="container">
  <div class="row d-flex align-items-center">
   <div class="col-md-6"><a href="#" class="logo"><img src="images/logo.png" alt="Logo" class="img-fluid"></a></div>
   <div class="col-md-6 justify-content-end">
    <div class="d-lg-flex justify-content-end">
     <div class="dropdown custom-account-circle">
      <button class="dropdown-toggle custom-account-circle-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <span class="account-small-image"><img src="images/profile-small.png" alt=""></span>Dropdown button
      </button>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li><a class="dropdown-item" href="#">Another action</a></li>
        <li><a class="dropdown-item" href="#">Something else here</a></li>
      </ul>
    </div>
    </div>
   
   </div>
  </div>
 </div>
</section>

<section class="section pb-3">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 mb-3">
    <div class="section-title text-center clearfix">
    <h2 class="heading text-white">My Account</h2>
   </div>
   </div>
  </div>
 </div>
 
 <div class="container">
  <div class="row">
   <div class="col-lg-3">
    <div class="sidebar h-100 clearfix">
     <div class="sidebar-profile text-center mb-4">
      <div class="profile-image"><img src="images/profile-img.png" alt="" class="img-fluid"></div>
      <span class="profile-name">Alexandra Carter</span>
       <a href="#" class="btn custom-btn custom-small-btn">Log out</a>
     </div>
     <ul class="account-nav">
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<g>
			<path d="M366.292,215.99L241.417,325.781c-0.167,0.146-0.333,0.292-0.479,0.448c-4.042,4.021-6.271,9.385-6.271,15.104     c0,11.76,9.563,21.333,21.333,21.333c5.667,0,11.021-2.208,15.563-6.75l109.792-124.875c3.708-4.219,3.5-10.604-0.479-14.583     C376.896,212.49,370.542,212.281,366.292,215.99z" fill="#000000" data-original="#000000" class=""></path>
			<path d="M256,85.333c-141.167,0-256,114.844-256,256c0,26.479,4.104,52.688,12.167,77.917c1.417,4.417,5.521,7.417,10.167,7.417     h467.333c4.646,0,8.75-3,10.167-7.417C507.896,394.021,512,367.813,512,341.333C512,200.177,397.167,85.333,256,85.333z      M458.667,352h31.26c-0.824,18.04-3.237,35.947-8.177,53.333H30.25c-4.94-17.387-7.353-35.293-8.177-53.333h31.26     C59.229,352,64,347.229,64,341.333c0-5.896-4.771-10.667-10.667-10.667h-31.46c1.581-34.919,10.68-67.865,25.948-97.208     l27.324,15.781c1.688,0.969,3.521,1.427,5.333,1.427c3.667,0,7.271-1.906,9.229-5.333c2.958-5.104,1.208-11.625-3.896-14.573     l-27.263-15.746c18.323-28.539,42.602-52.816,71.142-71.138l15.746,27.28c1.958,3.417,5.563,5.333,9.229,5.333     c1.813,0,3.646-0.458,5.333-1.427c5.104-2.948,6.854-9.469,3.896-14.573l-15.777-27.332c29.345-15.27,62.293-24.37,97.215-25.951     v31.46c0,5.896,4.771,10.667,10.667,10.667s10.667-4.771,10.667-10.667v-31.46c34.922,1.581,67.87,10.681,97.215,25.951     l-15.777,27.332c-2.958,5.104-1.208,11.625,3.896,14.573c1.688,0.969,3.521,1.427,5.333,1.427c3.667,0,7.271-1.917,9.229-5.333     l15.746-27.28c28.54,18.322,52.819,42.599,71.142,71.138l-27.263,15.746c-5.104,2.948-6.854,9.469-3.896,14.573     c1.958,3.427,5.563,5.333,9.229,5.333c1.812,0,3.646-0.458,5.333-1.427l27.324-15.781c15.268,29.344,24.367,62.289,25.948,97.208     h-31.46c-5.896,0-10.667,4.771-10.667,10.667C448,347.229,452.771,352,458.667,352z" fill="#000000" data-original="#000000" class=""></path>
		</g>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg></i>
        Dashboard
       </a>
      </li>
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 498.88 498.88" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<g>
			<path d="M386.88,273.44c-46.496,0-86.448,28.496-103.36,68.928l-24.64-3.792v-8.288c26.92-15.624,46.784-42.072,53.488-73.4     c19.44-2.712,34.512-19.272,34.512-39.448v-72c0-79.4-64.6-144-144-144h-13.704c-29.32,0-56.64,13.136-74.968,36.032     l-4.496,5.632c-31.4,16.424-50.832,48.448-50.832,84v90.336c0,20.176,15.072,36.736,34.512,39.448     c6.704,31.328,26.568,57.776,53.488,73.4v8.288l-41.312,6.352c-36.952,5.688-68.04,32.424-79.192,68.112L0,497.44h386.88     c61.76,0,112-50.24,112-112S448.64,273.44,386.88,273.44z M314.544,240.072c0.128-2.208,0.336-4.392,0.336-6.632v-38.528     c9.288,3.312,16,12.112,16,22.528C330.88,227.976,324.008,236.856,314.544,240.072z M74.88,217.44     c0-10.416,6.712-19.216,16-22.528v38.528c0,2.24,0.208,4.424,0.336,6.632C81.752,236.856,74.88,227.976,74.88,217.44z      M95.936,177.736c-7.88,0.584-15.096,3.4-21.056,7.904v-58.544c0-30.048,16.696-57.072,43.576-70.504l1.568-0.784l6.68-8.344     c15.272-19.08,38.032-30.024,62.472-30.024h13.704c70.576,0,128,57.424,128,128v40.208c-4.672-3.536-10.056-6.184-16-7.392     V145.44h-8c-12.344,0-23.808-6.136-30.656-16.408l-5.064-7.592h-8.984c-56.144,0-110.128,17.016-156.128,49.216L95.936,177.736z      M106.88,233.44v-43.832l8.344-5.84c43.296-30.312,94.112-46.328,146.952-46.328l0.736,0.472     c8.328,12.488,21.4,20.704,35.968,22.928v72.6c0,52.936-43.064,96-96,96C149.944,329.44,106.88,286.376,106.88,233.44z      M242.88,337.928v6.224l-0.448,1.336c-2.344,6.032-11.64,23.952-39.552,23.952c-27.904,0-37.184-17.84-39.544-23.928l-0.456-1.36     v-6.224c12.44,4.784,25.896,7.512,40,7.512S230.44,342.712,242.88,337.928z M99.944,481.44l6.872-55.008l-15.872-1.984     l-7.128,56.992H21.76l19.88-63.624c9.352-29.904,35.4-52.312,66.368-57.072l8.664-1.336l-11.96,29.896l31.432,15.712     l-15.352,30.712l58.768,45.712H99.944z M140.968,431.144l16.648-33.288l-32.568-16.28l10-24.992l14.384-2.216l37.512,112.528     L140.968,431.144z M174.608,379.32c7.6,3.704,16.928,6.12,28.272,6.12s20.672-2.416,28.272-6.12l-28.272,84.832L174.608,379.32z      M226.21,481.432l16.078-12.504l-9.832-12.632l-13.632,10.608l37.512-112.528l22.144,3.408c-2.184,8.56-3.472,17.48-3.552,26.688     l-26.784,13.392l16.648,33.288l-21.256,16.528l9.832,12.632l31.6-24.584l-15.352-30.712l6.584-3.296     c4.968,33.864,25.08,62.792,53.288,79.712H226.21z M386.88,481.44c-52.936,0-96-43.064-96-96c0-52.936,43.064-96,96-96     c52.936,0,96,43.064,96,96C482.88,438.376,439.816,481.44,386.88,481.44z" fill="#000000" data-original="#000000" class=""></path>
			<polygon points="377.232,431.936 347.232,388.696 334.088,397.816 371.136,451.216 386.376,451.216 440.448,325.04      425.744,318.736    " fill="#000000" data-original="#000000" class=""></polygon>
			<path d="M170.88,205.44c0-11.024-8.968-20-20-20s-20,8.976-20,20s8.968,20,20,20S170.88,216.464,170.88,205.44z M146.88,205.44     c0-2.208,1.8-4,4-4s4,1.792,4,4s-1.8,4-4,4S146.88,207.648,146.88,205.44z" fill="#000000" data-original="#000000" class=""></path>
			<path d="M254.88,225.44c11.032,0,20-8.976,20-20s-8.968-20-20-20c-11.032,0-20,8.976-20,20S243.848,225.44,254.88,225.44z      M254.88,201.44c2.2,0,4,1.792,4,4s-1.8,4-4,4s-4-1.792-4-4S252.68,201.44,254.88,201.44z" fill="#000000" data-original="#000000" class=""></path>
			<path d="M258.88,257.44h-16c0,22.056-17.944,40-40,40c-22.056,0-40-17.944-40-40h-16c0,30.88,25.128,56,56,56     S258.88,288.32,258.88,257.44z" fill="#000000" data-original="#000000" class=""></path>
		</g>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg></i>
        Accept job
       </a>
      </li>
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g xmlns="http://www.w3.org/2000/svg"><path d="m17.5 24c-3.584 0-6.5-2.916-6.5-6.5s2.916-6.5 6.5-6.5 6.5 2.916 6.5 6.5-2.916 6.5-6.5 6.5zm0-12c-3.032 0-5.5 2.467-5.5 5.5s2.468 5.5 5.5 5.5 5.5-2.467 5.5-5.5-2.468-5.5-5.5-5.5z" fill="#000000" data-original="#000000" class=""></path></g><g xmlns="http://www.w3.org/2000/svg"><path d="m13.265 22.235c-.128 0-.256-.049-.354-.146-.195-.195-.195-.512 0-.707l8.471-8.47c.195-.195.512-.195.707 0s.195.512 0 .707l-8.471 8.47c-.097.097-.225.146-.353.146z" fill="#000000" data-original="#000000" class=""></path></g><g xmlns="http://www.w3.org/2000/svg"><path d="m9.5 15h-6c-.276 0-.5-.224-.5-.5s.224-.5.5-.5h6c.276 0 .5.224.5.5s-.224.5-.5.5z" fill="#000000" data-original="#000000" class=""></path></g><g xmlns="http://www.w3.org/2000/svg"><path d="m8.5 18h-5c-.276 0-.5-.224-.5-.5s.224-.5.5-.5h5c.276 0 .5.224.5.5s-.224.5-.5.5z" fill="#000000" data-original="#000000" class=""></path></g><g xmlns="http://www.w3.org/2000/svg"><path d="m8.5 7c-1.103 0-2-.897-2-2s.897-2 2-2 2 .897 2 2-.897 2-2 2zm0-3c-.552 0-1 .449-1 1s.448 1 1 1 1-.449 1-1-.448-1-1-1z" fill="#000000" data-original="#000000" class=""></path></g><g xmlns="http://www.w3.org/2000/svg"><path d="m12 12c-.276 0-.5-.224-.5-.5v-1c0-.827-.673-1.5-1.5-1.5h-3c-.827 0-1.5.673-1.5 1.5v1c0 .276-.224.5-.5.5s-.5-.224-.5-.5v-1c0-1.378 1.121-2.5 2.5-2.5h3c1.379 0 2.5 1.122 2.5 2.5v1c0 .276-.224.5-.5.5z" fill="#000000" data-original="#000000" class=""></path></g><g xmlns="http://www.w3.org/2000/svg"><path d="m9.5 21h-7c-1.379 0-2.5-1.122-2.5-2.5v-16c0-1.378 1.121-2.5 2.5-2.5h12c1.379 0 2.5 1.122 2.5 2.5v6.06c0 .276-.224.5-.5.5s-.5-.224-.5-.5v-6.06c0-.827-.673-1.5-1.5-1.5h-12c-.827 0-1.5.673-1.5 1.5v16c0 .827.673 1.5 1.5 1.5h7c.276 0 .5.224.5.5s-.224.5-.5.5z" fill="#000000" data-original="#000000" class=""></path></g></g></svg></i>
        Reject job
       </a>
      </li>
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M494.01,488.583c-4.142,0-7.5,3.358-7.5,7.5v8.417c0,4.142,3.358,7.5,7.5,7.5c4.142,0,7.5-3.358,7.5-7.5v-8.417    C501.51,491.941,498.152,488.583,494.01,488.583z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M449.738,488.583c-4.142,0-7.5,3.358-7.5,7.5v8.417c0,4.142,3.358,7.5,7.5,7.5c4.142,0,7.5-3.358,7.5-7.5v-8.417    C457.238,491.941,453.88,488.583,449.738,488.583z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M405.465,488.583c-4.142,0-7.5,3.358-7.5,7.5v8.417c0,4.142,3.358,7.5,7.5,7.5c4.142,0,7.5-3.358,7.5-7.5v-8.417    C412.965,491.941,409.607,488.583,405.465,488.583z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M106.535,0c-4.142,0-7.5,3.358-7.5,7.5v8.417c0,4.142,3.358,7.5,7.5,7.5c4.142,0,7.5-3.358,7.5-7.5V7.5    C114.035,3.358,110.677,0,106.535,0z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M62.262,0c-4.142,0-7.5,3.358-7.5,7.5v8.417c0,4.142,3.358,7.5,7.5,7.5c4.142,0,7.5-3.358,7.5-7.5V7.5    C69.762,3.358,66.404,0,62.262,0z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M17.99,0c-4.142,0-7.5,3.358-7.5,7.5v8.417c0,4.142,3.358,7.5,7.5,7.5c4.142,0,7.5-3.358,7.5-7.5V7.5    C25.49,3.358,22.132,0,17.99,0z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M435.558,231.352l-87.999-87.983l-73.125-73.125c-3.882-3.883-9.256-6.11-14.743-6.11H87.124    c-8.599,0-15.983,4.936-19.27,12.881c-3.283,7.937-1.547,16.636,4.523,22.695c42.589,42.644,133.354,133.416,156.214,156.276    C205.788,278.8,115.254,369.373,72.386,412.283c-6.079,6.067-7.815,14.767-4.532,22.703c3.287,7.945,10.67,12.881,19.27,12.881    h172.567c5.487,0,10.861-2.227,14.743-6.109l161.125-161.14c0.001-0.001,0.002-0.002,0.003-0.004    C449.123,267.033,449.123,244.936,435.558,231.352z M424.948,270.015l0.003-0.004l-161.124,161.14    c-1.09,1.09-2.598,1.715-4.136,1.715h-76.924c48.665-46.937,97.766-96.692,153.615-155.642    c11.307-11.398,11.418-31.614,0.224-44.208c-0.098-0.11-0.198-0.216-0.302-0.32c-30.349-30.349-59.015-59.015-88.063-87.738    c-2.946-2.914-7.695-2.886-10.606,0.06c-2.913,2.945-2.886,7.694,0.06,10.606c28.963,28.639,57.56,57.235,87.83,87.505    c5.118,5.925,6.316,17.423,0.173,23.566c-0.048,0.048-0.095,0.096-0.142,0.145c-59.289,62.583-110.934,114.758-162.53,164.197    c-0.572,0.549-1.037,1.167-1.397,1.828H87.124c-3.631,0-5.058-2.767-5.409-3.615c-0.349-0.845-1.291-3.799,1.275-6.36    c49.278-49.325,161.512-161.605,161.512-161.605c2.928-2.929,2.928-7.677-0.001-10.605    c-1.123-1.123-112.812-112.813-161.518-161.58c-2.558-2.554-1.617-5.508-1.268-6.353c0.351-0.848,1.777-3.615,5.409-3.615h74.509    c0.383,0.703,0.879,1.358,1.501,1.93c7.913,7.285,15.612,15.349,23.057,23.148c8.146,8.533,16.57,17.356,25.369,25.267    c1.433,1.289,3.226,1.923,5.012,1.923c2.054,0,4.099-0.838,5.58-2.486c2.77-3.08,2.518-7.822-0.563-10.591    c-8.373-7.528-16.229-15.757-24.547-24.47c-4.654-4.874-9.405-9.849-14.285-14.72h76.935c1.538,0,3.046,0.625,4.136,1.716    l73.126,73.126l87.995,87.979C432.673,249.691,432.673,262.278,424.948,270.015z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg></i>
        Next step
       </a>
      </li>
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 128 128" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path xmlns="http://www.w3.org/2000/svg" d="m102.635 23.6-13.335-13.337a1.75 1.75 0 0 0 -1.237-.513h-61.463a1.75 1.75 0 0 0 -1.75 1.75v105a1.75 1.75 0 0 0 1.75 1.75h74.8a1.75 1.75 0 0 0 1.75-1.75v-91.664a1.75 1.75 0 0 0 -.515-1.236zm-12.823-7.875 7.361 7.361h-7.361zm-61.46 99.025v-101.5h57.96v11.586a1.75 1.75 0 0 0 1.75 1.75h11.586v88.164z" fill="#000000" data-original="#000000" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m90.619 73.822h-53.238a1.75 1.75 0 1 0 0 3.5h53.238a1.75 1.75 0 0 0 0-3.5z" fill="#000000" data-original="#000000" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m37.381 86.625h26.619a1.75 1.75 0 0 0 0-3.5h-26.619a1.75 1.75 0 0 0 0 3.5z" fill="#000000" data-original="#000000" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m90.619 92.428h-53.238a1.75 1.75 0 1 0 0 3.5h53.238a1.75 1.75 0 0 0 0-3.5z" fill="#000000" data-original="#000000" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m64 101.732h-26.619a1.75 1.75 0 1 0 0 3.5h26.619a1.75 1.75 0 0 0 0-3.5z" fill="#000000" data-original="#000000" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m61.256 62.8a11.667 11.667 0 1 0 16.256-16.361v-24.388a1.75 1.75 0 0 0 -1.75-1.75h-39a1.75 1.75 0 0 0 -1.75 1.75v39a1.75 1.75 0 0 0 1.75 1.75zm9.37 1.236a8.182 8.182 0 1 1 8.182-8.182 8.191 8.191 0 0 1 -8.182 8.183zm-11.114-40.236v7.61l-2.157-1.726a1.751 1.751 0 0 0 -2.187 0l-2.156 1.726v-7.61zm-21 0h11v11.25a1.75 1.75 0 0 0 2.843 1.367l3.907-3.125 3.907 3.125a1.75 1.75 0 0 0 2.843-1.367v-11.25h11v20.878a11.68 11.68 0 0 0 -14.547 14.622h-20.953z" fill="#000000" data-original="#000000" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m73.242 52.279-4.042 4.421-1.4-1.1a1.75 1.75 0 0 0 -2.164 2.751l2.681 2.109a1.75 1.75 0 0 0 2.375-.2l5.135-5.625a1.75 1.75 0 0 0 -2.585-2.359z" fill="#000000" data-original="#000000" class=""></path></g></svg></i>
        Dispatch job
       </a>
      </li>
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M310,190c-5.52,0-10,4.48-10,10s4.48,10,10,10c5.52,0,10-4.48,10-10S315.52,190,310,190z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M500.281,443.719l-133.48-133.48C388.546,277.485,400,239.555,400,200C400,89.72,310.28,0,200,0S0,89.72,0,200    s89.72,200,200,200c39.556,0,77.486-11.455,110.239-33.198l36.895,36.895c0.005,0.005,0.01,0.01,0.016,0.016l96.568,96.568    C451.276,507.838,461.319,512,472,512c10.681,0,20.724-4.162,28.278-11.716C507.837,492.731,512,482.687,512,472    S507.837,451.269,500.281,443.719z M305.536,345.727c0,0.001-0.001,0.001-0.002,0.002C274.667,368.149,238.175,380,200,380    c-99.252,0-180-80.748-180-180S100.748,20,200,20s180,80.748,180,180c0,38.175-11.851,74.667-34.272,105.535    C334.511,320.988,320.989,334.511,305.536,345.727z M326.516,354.793c10.35-8.467,19.811-17.928,28.277-28.277l28.371,28.371    c-8.628,10.183-18.094,19.65-28.277,28.277L326.516,354.793z M486.139,486.139c-3.78,3.78-8.801,5.861-14.139,5.861    s-10.359-2.081-14.139-5.861l-88.795-88.795c10.127-8.691,19.587-18.15,28.277-28.277l88.798,88.798    C489.919,461.639,492,466.658,492,472C492,477.342,489.919,482.361,486.139,486.139z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M200,40c-88.225,0-160,71.775-160,160s71.775,160,160,160s160-71.775,160-160S288.225,40,200,40z M200,340    c-77.196,0-140-62.804-140-140S122.804,60,200,60s140,62.804,140,140S277.196,340,200,340z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
	<g>
		<path d="M312.065,157.073c-8.611-22.412-23.604-41.574-43.36-55.413C248.479,87.49,224.721,80,200,80c-5.522,0-10,4.478-10,10    c0,5.522,4.478,10,10,10c41.099,0,78.631,25.818,93.396,64.247c1.528,3.976,5.317,6.416,9.337,6.416    c1.192,0,2.405-0.215,3.584-0.668C311.472,168.014,314.046,162.229,312.065,157.073z" fill="#000000" data-original="#000000" class=""></path>
	</g>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg></i>
        Search job
       </a>
      </li>
      <li>
       <a href="#" class="d-flex align-items-center">
        <i class="account-nav-svg"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g xmlns="http://www.w3.org/2000/svg"><path d="m411 262.862v-47.862c0-69.822-46.411-129.001-110-148.33v-21.67c0-24.813-20.187-45-45-45s-45 20.187-45 45v21.67c-63.59 19.329-110 78.507-110 148.33v47.862c0 61.332-23.378 119.488-65.827 163.756-4.16 4.338-5.329 10.739-2.971 16.267s7.788 9.115 13.798 9.115h136.509c6.968 34.192 37.272 60 73.491 60 36.22 0 66.522-25.808 73.491-60h136.509c6.01 0 11.439-3.587 13.797-9.115s1.189-11.929-2.97-16.267c-42.449-44.268-65.827-102.425-65.827-163.756zm-170-217.862c0-8.271 6.729-15 15-15s15 6.729 15 15v15.728c-4.937-.476-9.94-.728-15-.728s-10.063.252-15 .728zm15 437c-19.555 0-36.228-12.541-42.42-30h84.84c-6.192 17.459-22.865 30-42.42 30zm-177.67-60c34.161-45.792 52.67-101.208 52.67-159.138v-47.862c0-68.925 56.075-125 125-125s125 56.075 125 125v47.862c0 57.93 18.509 113.346 52.671 159.138z" fill="#000000" data-original="#000000" class=""></path><path d="m451 215c0 8.284 6.716 15 15 15s15-6.716 15-15c0-60.1-23.404-116.603-65.901-159.1-5.857-5.857-15.355-5.858-21.213 0s-5.858 15.355 0 21.213c36.831 36.831 57.114 85.8 57.114 137.887z" fill="#000000" data-original="#000000" class=""></path><path d="m46 230c8.284 0 15-6.716 15-15 0-52.086 20.284-101.055 57.114-137.886 5.858-5.858 5.858-15.355 0-21.213-5.857-5.858-15.355-5.858-21.213 0-42.497 42.497-65.901 98.999-65.901 159.099 0 8.284 6.716 15 15 15z" fill="#000000" data-original="#000000" class=""></path></g></g></svg></i>
        Notification
       </a>
      </li>
     </ul>
    </div>
   
   
   </div>
   <div class="col-lg-9">
   <form method="post" action="#">
    <div class="shadow-wrap mb-4 clearfix">
     <div class="d-lg-flex justify-content-between mb-3">
      <h3 class="inner-heading">My Profile</h3>
      <a href="#" class="d-flex align-items-center text-decoration-none text-dark">
       <i class="d-inline-block svg-20 me-2">
        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 511.984 511.984" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g xmlns="http://www.w3.org/2000/svg"><path d="m415 221.984c-8.284 0-15 6.716-15 15v220c0 13.785-11.215 25-25 25h-320c-13.785 0-25-11.215-25-25v-320c0-13.785 11.215-25 25-25h220c8.284 0 15-6.716 15-15s-6.716-15-15-15h-220c-30.327 0-55 24.673-55 55v320c0 30.327 24.673 55 55 55h320c30.327 0 55-24.673 55-55v-220c0-8.284-6.716-15-15-15z" fill="#000000" data-original="#000000" class=""></path><path d="m501.749 38.52-28.285-28.285c-13.645-13.646-35.849-13.646-49.497 0l-226.273 226.274c-2.094 2.094-3.521 4.761-4.103 7.665l-14.143 70.711c-.983 4.918.556 10.002 4.103 13.548 2.841 2.841 6.668 4.394 10.606 4.394.979 0 1.963-.096 2.941-.291l70.711-14.143c2.904-.581 5.571-2.009 7.665-4.103l226.275-226.273s.001 0 .001-.001c13.645-13.645 13.645-35.849-.001-49.496zm-244.276 251.346-44.194 8.84 8.84-44.194 184.17-184.173 35.356 35.356zm223.063-223.062-17.678 17.678-35.356-35.356 17.677-17.677c1.95-1.95 5.122-1.951 7.072-.001l28.284 28.285c1.951 1.949 1.951 5.122.001 7.071z" fill="#000000" data-original="#000000" class=""></path></g></g></svg>
       </i>
       Edit profile
      </a>
     </div>
     
     <div class="form-section clearfix">
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputText" placeholder="">
                <label for="inputText">Name</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="tel" class="form-control" id="inputPhone" placeholder="">
                <label for="inputPhone">Phone</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="email" class="form-control" id="inputEmail" placeholder="">
                <label for="inputText">Email</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputAddress" placeholder="">
                <label for="inputAddress">Address</label>
              </div>
            </div>
          </div>
          
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <select class="form-select" id="floatingSelectGrid" aria-label="Floating label select example">
                  <option selected="">Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="floatingSelectGrid">Job role</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <select class="form-select" id="floatingSelectGrid2" aria-label="Floating label select example">
                  <option selected="">Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="floatingSelectGrid2">Travel for work</label>
              </div>
            </div>
          </div>
          
          
          
      </div>
     
    </div>
    
    <div class="shadow-wrap clearfix">
     
     
     <div class="form-section clearfix">
        
          <div class="row mb-4">
            <div class="col-md-9">
              <label for="formFile" class="form-label">Proof to work photo</label>
              <input class="form-control form-control-lg" type="file" id="formFile">
            </div>
            <div class="col-md-3">
             <div class="upload-photo-show-box">
              <img src="images/upload-image.png" class="img-fluid">
              <a class="cross-sign" href="#">
               <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path xmlns="http://www.w3.org/2000/svg" d="m256 0c-141.164062 0-256 114.835938-256 256s114.835938 256 256 256 256-114.835938 256-256-114.835938-256-256-256zm0 0" fill="#f44336" data-original="#f44336" class=""></path><path xmlns="http://www.w3.org/2000/svg" d="m350.273438 320.105469c8.339843 8.34375 8.339843 21.824219 0 30.167969-4.160157 4.160156-9.621094 6.25-15.085938 6.25-5.460938 0-10.921875-2.089844-15.082031-6.25l-64.105469-64.109376-64.105469 64.109376c-4.160156 4.160156-9.621093 6.25-15.082031 6.25-5.464844 0-10.925781-2.089844-15.085938-6.25-8.339843-8.34375-8.339843-21.824219 0-30.167969l64.109376-64.105469-64.109376-64.105469c-8.339843-8.34375-8.339843-21.824219 0-30.167969 8.34375-8.339843 21.824219-8.339843 30.167969 0l64.105469 64.109376 64.105469-64.109376c8.34375-8.339843 21.824219-8.339843 30.167969 0 8.339843 8.34375 8.339843 21.824219 0 30.167969l-64.109376 64.105469zm0 0" fill="#fafafa" data-original="#fafafa" class=""></path></g></svg>
              </a>
             </div>
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-12">
              <input type="submit" class="w-100 btn btn-lg custom-btn mb-3" value="Update Profile">
            </div>
          </div>
          
        
      </div>
     
    </div>
    
    </form>
    
   </div>
  </div>
 </div>
 
 
 

</section>

<p class="text-center text-white py-3">Copyright © 2022 <a href="#" class="text-decoration-none" target="_blank" style="color:#ffe400;">E Services uk</a>. All rights reserved.</p>


<!-- jQuery -->
<script src="js/jquery.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
$(window).resize(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
</script>



</body>
</html>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>E Services</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Mulish:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<link rel="stylesheet" href="css/animate.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/media.css" rel="stylesheet">
</head>
<body>
<section class="section d-flex full-height justify-content-center align-items-center">
  <div class="login-wrap registration-box w-100 m-auto clearfix">
    <div class="login-box w-100 clearfix">
      <div class="login-logo"><a href="#"><img src="images/logo.png" alt="Logo" class="img-fluid"></a></div>
      <div class="section-title text-center clearfix">
        <h2 class="heading">Register to Eservices</h2>
        <span class="sub-heading">Create an Account</span> </div>
      <div class="form-section pt-4 clearfix">
        <form method="post" action="#">
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputText" placeholder="">
                <label for="inputText">Name</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="tel" class="form-control" id="inputPhone" placeholder="">
                <label for="inputPhone">Phone</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <input type="email" class="form-control" id="inputEmail" placeholder="">
                <label for="inputText">Email</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <input type="text" class="form-control" id="inputAddress" placeholder="">
                <label for="inputAddress">Address</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <label for="formFile" class="form-label">Proof to work photo (Passport or NI)</label>
              <input class="form-control" type="file" id="formFile">
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="form-floating">
                <select class="form-select" id="floatingSelectGrid" aria-label="Floating label select example">
                  <option selected>Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="floatingSelectGrid">Job role</label>
              </div>
            </div>
            <div class="col-md-6 form-floating">
              <div class="form-floating">
                <select class="form-select" id="floatingSelectGrid2" aria-label="Floating label select example">
                  <option selected>Choose...</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
                <label for="floatingSelectGrid2">Travel for work</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="gridCheck1">
                <label class="form-check-label" for="gridCheck1"> I agree to the terms and conditions as set out by the user agreement.</label>
              </div>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-md-12">
              <input type="submit" class="w-100 btn btn-lg custom-btn mb-3" value="Create an Account">
            </div>
          </div>
          
        </form>
      </div>
      <div class="d-lg-flex form-bottom"> <span class="w-100 text-center">Already a Member? <a href="#" class="text-dark fw-semibold">Sign in</a></span> </div>
    </div>
  </div>
</section>

<!-- jQuery --> 
<script src="js/jquery.min.js"></script> 
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script> 
<script>
$(document).ready(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
$(window).resize(function(){
    $('.full-height').css('height', $(window).height());
    // Comma, not colon ----^
});
</script>
<script>
var newClass = window.location.href;
newClass = newClass.substring(newClass.lastIndexOf('/')+1, 5);
$('body').addClass('overflow-hidden');
</script>
</body>
</html>

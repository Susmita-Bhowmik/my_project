<?php include 'db_conn.php';
$response['image'] =($_FILES["photo_image"]["name"]);
$response['full_name'] = $_POST['full_name']; 
$response['user_email'] = $_POST['user_email']; 

if(($_FILES["photo_image"]["name"]) && $_POST['full_name']){

$name  = $_POST['full_name'];
$file = $_FILES['photo_image'];
$email = $_POST['user_email']; 


$filename  = ($_FILES["photo_image"]["name"]);
$filepath  = $_FILES["photo_image"]["tmp_name"];
$fileerror  = $file['error'];

if($fileerror==0){
	$desfile = 'uploads/'.$filename;
	move_uploaded_file($filepath, $desfile);
}
$sql     = "INSERT INTO images (img_name,name,email) VALUES ('$filename','$name','$email')";
 $result = mysqli_query($conn, $sql);

 if($result){
	 $response['full_name'] =$name;
	 $response['image'] =' <img src="uploads/'.$filename.'">';
     $response['user_email'];
 	
 }
}
echo json_encode($response);
?>
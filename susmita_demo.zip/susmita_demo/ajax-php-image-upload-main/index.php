<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ajax</title>
</head>
<body>
    
    <form id="datafiles" method="post" enctype="multipart/form-data" onsubmit="return false">
	<input type="text"  id="full_name" name="full_name"><br><br>
	<input type="email" name="user_email" id="user_email"><br><br>
	<input type="file"  id="photo_image" name="photo_image"><br><br>
	<button id="submit">Upload</button><br><br>
	</form>
	<table border="1">
		<th>Name</th>
		<th>Photo</th>
		<th>Email</th>
		<tr>
			<td><div id="show"></div></td>
			<td><div id="show2"></div></td>
			<td><div id="show3"></div></td>
		</tr>
	</table>
	
    

    <style type="text/css">
    	img{
    		    height: 436px;
    			width: 250px;
    	}
    </style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script type="text/javascript">
	

      
     $(document).ready(function(e){
    // Submit form data via Ajax
    $("#datafiles").on('submit', function(e){
        e.preventDefault();
  		 if($('#full_name').val()==""||$('#photo_image').val()=="" ) {
  		 	alert('Please fill the fields!');
  		 	$('#full_name').focus();
  		 	$('#user_email').focus();
  		 }
        $.ajax({
            type: 'POST',
            url: 'insert.php',
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData:false,
            success: function(response){
				// alert(response.status);
				$('#show').html(response.full_name);
				$('#show2').html(response.image);
				$('#show3').html(response.user_email);
				//alert(response.message);
            }
        });
    });
});
 

</script>
</body>
</html>
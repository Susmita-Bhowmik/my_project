<?php 
session_start();
$_SESSION["user_id"] = "";
$_SESSION["user_name"] = "";
$_SESSION["user_email"] = "";
if($_SESSION["user_id"]=="")
{
	 ?>
  <script type="text/javascript">
    alert("logout");
    window.location="login.php";

  </script>
  <?php
}
?>
<?php 


$con = new mysqli('localhost','root','','company_db');
if(!$con){
	echo 'failed!';
}



 ?>